import static org.junit.Assert.*;

import org.junit.Test;

public class TestCases {

	
		@Test
	   public void testLowestWithNonEmptyArray() {
		System.out.println("********Running test Lowest with Non empty array ******");
		int[] numbers= {20, 5, 11, 70, 45, 12, 9, 3};
		findValue val = new findValue();
		Integer result = val.find_lowest(numbers);
		System.out.println("MinValue is :  " + result );
		try{
			assertNotNull(result);
			}
			catch(Throwable t){
				System.out.println("Error");
			
			}
		
	   }
	@Test
	   public void testLowestWithEmptyArray() {
		System.out.println("********Running test Lowest with empty array ******");
		int[] numbers1= null;
		findValue val = new findValue();
		Integer result = val.find_lowest(numbers1);
		System.out.println("MinValue is :  " + result );
		try{
			assertNotNull(result);
			}
			catch(Throwable t){
				System.out.println("Error");
			
			}
		
	   }			
	
	@Test
	   public void testSecLowestWithNonEmptyArray() {
		System.out.println("********Running test Second Lowest with Non empty array ******");
		int[] numbers= {20, 5, 11, 70, 45, 12, 9, 3};
		findValue val = new findValue();
		Integer result = val.find_secondLowest(numbers);
		System.out.println("Second MinValue is :  " + result );
		try{
			assertNotNull(result);
			}
			catch(Throwable t){
				System.out.println("Error");
			
			}
		
	   }
	@Test
	   public void testSecLowestWithEmptyArray() {
		System.out.println("********Running test Second Lowest with empty array ******");
		int[] numbers1= null;
		findValue val = new findValue();
		Integer result = val.find_secondLowest(numbers1);
		System.out.println("Second MinValue is :  " + result );
		try{
		assertNotNull(result);
		}
		catch(Throwable t){
			System.out.println("Error");
		
		}
	   }	
	

}
