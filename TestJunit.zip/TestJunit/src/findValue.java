

import static org.junit.Assert.*;

import org.junit.Test;






public class findValue implements findValueInArray{
	
	
	
	@Test
	public Integer find_lowest(int[] ArryOfNumbers) {
	int minValue=0;
	
	if (ArryOfNumbers !=null)
	{
		 minValue=ArryOfNumbers[0];
		 for(int i=0;i<ArryOfNumbers.length;i++)
		 {
		        if(ArryOfNumbers[i]<minValue)
		        {
		        	minValue=ArryOfNumbers[i];
		        }
		 }
		 return minValue;
	}else{
		
		return null;
		
	}
	

}	
	

	@Test
	public Integer find_secondLowest(int[] ArryOfNumbers) {
	int sec_low=0;
	
	if (ArryOfNumbers !=null)
	{
		sec_low=ArryOfNumbers[0];
		int lowestValue= this.find_lowest(ArryOfNumbers);
		for (int i=0; i<ArryOfNumbers.length; i++)
		{
			if (ArryOfNumbers[i]<sec_low && ArryOfNumbers[i]!=lowestValue)
			{
			sec_low= ArryOfNumbers[i];
			}
		}
		return sec_low;	

	}else{
		
		return null;
		
		
	}
		
	}

}
