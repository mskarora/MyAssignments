

public interface findValueInArray {
	public Integer find_lowest(int[] arr);
	public Integer find_secondLowest(int[] arr);
}
